import React from "react";
const Spinner = () => <div className="mySpinner" />;
export default Spinner;
