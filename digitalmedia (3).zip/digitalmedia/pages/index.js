import React from "react";
import axios from "axios";
import baseUrl from "../utils/baseUrl";

function Index() {
    return <div>Homepage</div>;
}

export default Index;
