module.exports = {
  env: {
    CLOUDINARY_URL: "https://api.cloudinary.com/v1_1/dpntk4wlm"

  }
};
